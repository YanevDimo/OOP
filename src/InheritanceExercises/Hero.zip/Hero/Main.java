package InheritanceExercises.Hero;

public class Main {
    public static void main(String[] args) {

    }
}
