package InheritanceExercises.NeedForSpeed;

public class Main {
    public static void main(String[] args) {

    }
}
